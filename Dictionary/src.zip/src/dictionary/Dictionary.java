package dictionary;

import java.io.FileNotFoundException;

class Word{
    private String spelling;    // nội dung từ
    private String explain;     // giải nghĩa

    public Word() {
    }

    public Word(String spelling, String explain) {
        this.spelling = spelling;
        this.explain = explain;
    }
    
    public void setSPELLING(String st){
        this.spelling = st;
    }
    public String getSPELLING(){
        return this.spelling;
    }
    
    public void setEXPLAIN(String st){
        this.explain = st;
    }
    public String getEXPLAIN(){
        return this.explain;
    }
}

class Diction{
    public Word [] words;    // danh sách từ
    public int N;               // độ dài từ điển

    public Diction() {
        N=0;
        words = new Word[700000];
    }
}

public class Dictionary{

    /**
     * @param args
     * @throws java.io.FileNotFoundException
     */

    public static void main(String[] args) throws FileNotFoundException {
        Application ns = new Application();
        ns.setVisible(true);
        //ns.insertFromFile();
        //ns.showAllWord();
    }
    
}
