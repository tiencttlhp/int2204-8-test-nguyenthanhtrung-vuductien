/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionary;

import com.sun.glass.events.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.String;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import com.sun.speech.freetts.VoiceManager;

/**
 *
 * @author TienLuong
 */
public final class Application extends javax.swing.JFrame {

    DefaultListModel mode11;
    
    
    public Application() throws FileNotFoundException {
        mode11 = new DefaultListModel();
        initComponents();
        insertFromFile();
    }

    
    //
    
    Diction d = new Diction();
    
    // hiển thị toàn bộ từ
    public void showAllWord(){
        mode11.removeAllElements(); 
        ListWords.setModel(mode11);
        for (int i=0; i<d.N; i++){
            mode11.addElement(d.words[i].getSPELLING());
        }
        ListWords.setModel(mode11);
    }
    
    // load từ mới từ file
    public void insertFromFile() throws FileNotFoundException{
        File inFile = new File("E_V.txt");
        try (FileReader fileReader = new FileReader(inFile)) {
            BufferedReader reader = new BufferedReader(fileReader);
        
            String line;
            while( (line = reader.readLine())  != null )
            {
                String target = line.substring(0,line.indexOf("<html>"));
                String explain = line.substring(line.indexOf("<html>"));
                d.words[d.N] = new Word(target,explain);
                d.N++;      // tăng số lượng từ
            }
            showAllWord();  // hiển thị từ mới
        } catch (IOException ex) {
            Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    // tìm từ và in ra màn hình nghĩa của từ
    public void dictionaryLookup(String st){
        boolean kt = false;
        for (int i=0; i<d.N; i++){
            if (st.compareToIgnoreCase(d.words[i].getSPELLING()) == 0){
                nghiaHienThi.setContentType("text/html");
                nghiaHienThi.setText(d.words[i].getEXPLAIN());
                kt = true; break;
            }
        }
        if(kt==false) JOptionPane.showMessageDialog(this, "Không tìm thấy từ cần tìm!");
    }
    
    // hiển thị các từ gần giống vs từ cần tìm
    public void dictionaryShow(String st){
        for(int i=0; i<d.N ; i++){
            if (d.words[i].getSPELLING().toUpperCase().indexOf(st.toUpperCase()) == 0 ){
                mode11.addElement(d.words[i].getSPELLING());
            }
        }
        ListWords.setModel(mode11);
    }
    
    // ghi ra file
    public void dictionaryExportToFile(){
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter("dictionaries.txt");
            bw = new BufferedWriter(fw);
            for (int i=0; i< d.N ; i++) bw.write(d.words[i].getSPELLING() + "\n"+ d.words[i].getEXPLAIN() + "\n");
            //bw.write(st2);
        } catch (IOException e) {
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
            }
        }
        
        showAllWord();
    }
    
    // thêm từ
    public void addWord(String st1, String st2){
        d.words[d.N] = new Word(st1, st2);
        d.N++;
        dictionaryExportToFile();   // ghi vào file
        //showAllWord();
    }
    
    // xóa 1 từ
    public void deleteWord(String st){
        int i=0;
        while (i<d.N && !st.equals(d.words[i].getSPELLING())){
            i++; 
        }
        if (st.equals(d.words[i].getSPELLING())){
            for (int j=i; j<d.N-1; j++){
                d.words[j].setSPELLING(d.words[j+1].getSPELLING());
                d.words[j].setEXPLAIN(d.words[j+1].getEXPLAIN());
            }
            System.out.println("\n");
            d.N--;
            dictionaryExportToFile();       // ghi
        }
    }
    
    // sửa chưax từ
    public void editWords(String st){
//        int i=0;
//        while (i<d.N && !st.equals(d.words[i].getSPELLING())){
//            i++; 
//        }
//        if (i<d.N){
//            d.words[i].setSPELLING(newWords.getText());
//            d.words[i].setEXPLAIN(nghiaHienThi.getText());
//            dictionaryExportToFile();
//        }
    }
    
    public static void speech(String text) {
        VoiceManager voiceManager = VoiceManager.getInstance();
        com.sun.speech.freetts.Voice syntheticVoice = voiceManager.getVoice("kevin16");
        syntheticVoice.allocate();
        syntheticVoice.speak(text);
        syntheticVoice.deallocate();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jScrollPane2 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jPanel1 = new javax.swing.JPanel();
        addButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        timTuButton = new javax.swing.JButton();
        inputText = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        ListWords = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        nghiaHienThi = new javax.swing.JEditorPane();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        jScrollPane2.setViewportView(jTree1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Dictionary");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));
        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));
        jPanel1.setOpaque(false);

        addButton.setText("Thêm từ");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        editButton.setText("Chỉnh sửa");
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Xóa từ");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nhập từ cần tra cứu", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel2.setForeground(new java.awt.Color(255, 255, 0));

        timTuButton.setBackground(new java.awt.Color(102, 255, 204));
        timTuButton.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        timTuButton.setForeground(new java.awt.Color(255, 0, 0));
        timTuButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/search (1).png"))); // NOI18N
        timTuButton.setText("Tra cứu");
        timTuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timTuButtonActionPerformed(evt);
            }
        });

        inputText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                inputTextKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                inputTextKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inputTextKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(inputText, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timTuButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputText, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timTuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        ListWords.setBackground(new java.awt.Color(204, 204, 255));
        ListWords.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 255, 0)), "Chọn từ trong danh sách", javax.swing.border.TitledBorder.LEADING, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(204, 0, 0))); // NOI18N
        ListWords.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        ListWords.setSelectionBackground(new java.awt.Color(255, 51, 51));
        ListWords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ListWordsMouseClicked(evt);
            }
        });
        ListWords.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ListWordsKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(ListWords);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loa.png"))); // NOI18N
        jButton1.setAutoscrolls(true);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        nghiaHienThi.setBackground(new java.awt.Color(204, 204, 204));
        nghiaHienThi.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 0, 0)), "Nghĩa của từ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 18), new java.awt.Color(0, 0, 102))); // NOI18N
        nghiaHienThi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jScrollPane1.setViewportView(nghiaHienThi);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(editButton)
                                .addGap(18, 18, 18)
                                .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 629, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteButton)
                            .addComponent(editButton)
                            .addComponent(addButton)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(57, 57, 57))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        getContentPane().add(jPanel1, gridBagConstraints);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bk.jpg"))); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        getContentPane().add(jLabel1, gridBagConstraints);

        jMenuBar1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 0, 0)));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // sự kiện click chuột nút Tra Cứu
    private void timTuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timTuButtonActionPerformed
        // TODO add your handling code here:
        String gm = inputText.getText().trim();
        if (!gm.equals("")) {   //nếu không rỗng thì tìm kiếm
            dictionaryLookup(gm); 
        }
    }//GEN-LAST:event_timTuButtonActionPerformed

    private void inputTextKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputTextKeyTyped
        // TODO add your handling code here: KHI 1 KEY ĐƯỢC GÕ
        
    }//GEN-LAST:event_inputTextKeyTyped

    private void inputTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputTextKeyPressed
        // TODO add your handling code here: KHI ĐÃ ẤN
        
    }//GEN-LAST:event_inputTextKeyPressed

    private void inputTextKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputTextKeyReleased
        // TODO add your handling code here: KHI 1 KEY ĐƯỢC NHẢ RA
        String st = inputText.getText().trim();
       
        if (!st.equals("")){
            mode11.removeAllElements(); 
            ListWords.setModel(mode11);
            //nghiaHienThi.setContentType("");
            nghiaHienThi.setText("\0");
            if(evt.getKeyCode() == KeyEvent.VK_ENTER){
                String gm = inputText.getText();
                dictionaryLookup(gm);   // tìm từ
            }
            dictionaryShow(inputText.getText());  //tìm các từ gần giống
        }
        else showAllWord();
    }//GEN-LAST:event_inputTextKeyReleased

    private void ListWordsKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ListWordsKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){      // nếu ấn nút enter
                String gm = ListWords.getSelectedValue();
                inputText.setText(gm);
                dictionaryLookup(gm);
            }
    }//GEN-LAST:event_ListWordsKeyReleased

    private void ListWordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListWordsMouseClicked
        // TODO add your handling code here:
        String gm = ListWords.getSelectedValue().trim();
        inputText.setText(gm);
        dictionaryLookup(gm);
    }//GEN-LAST:event_ListWordsMouseClicked

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
//        if(newWords.getText().equals("") || shownMeans.getText().equals("")){
//            JOptionPane.showMessageDialog(rootPane, "Empty", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//        else addWord(newWords.getText(), shownMeans.getText());
    }//GEN-LAST:event_addButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        String st = ListWords.getSelectedValue();
        //deleteWord(st);
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        // TODO add your handling code here:
//        String st = ListWords.getSelectedValue();
//        if(newWords.getText().equals("") || shownMeans.getText().equals("")){
//            JOptionPane.showMessageDialog(rootPane, "Empty", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//        else {
//            editWords(st);
//            JOptionPane.showMessageDialog(rootPane, "Ok!", "Edit Words", JOptionPane.CANCEL_OPTION);
//        }
    }//GEN-LAST:event_editButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String st = inputText.getText();
        speech(st);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Application.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Application.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Application.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Application.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ListWords;
    private javax.swing.JButton addButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton editButton;
    private javax.swing.JTextField inputText;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTree jTree1;
    private javax.swing.JEditorPane nghiaHienThi;
    private javax.swing.JButton timTuButton;
    // End of variables declaration//GEN-END:variables

}